<!-- page content -->
<section class="page">
    
            
            <div class="container">
                <div class="row">
                                
                        
                            <!-- span12 -->
                            <div class="span12"><?php the_content(); ?></div>

                </div>
                <!-- end row -->
            </div>
            <!-- end container -->


</section>
<!-- end page content -->