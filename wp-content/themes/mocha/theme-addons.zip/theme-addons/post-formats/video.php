<!-- post image / video -->
<div class="post-image">
    
        
        <div class="video-wrapper">
            
                 <?php echo get_post_meta(get_the_ID() , 'video' , true); ?>



        </div>
        <!-- end video wrapper -->



</div>
<!-- end audio / post image -->